<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Maverick</key>
	<dict>
		<key>Carrier ID</key>
		<string></string>
		<key>PRI Revision</key>
		<string>0.1.030</string>
	</dict>
	<key>Feature Settings</key>
	<dict>
		<key>Preferred Mode</key>
		<string>TDS_GSM_WCDMA_LTE</string>
		<key>Rat Acq Order</key>
		<string>WGLT</string>	
		<key>RTRE Config</key>
		<string>NV_ONLY</string>
	</dict>
	<key>WCDMA</key>
	<dict>
		<key>ANITE GCF</key>
		<true/>
		<key>Band Class Pref b16-b31</key>
		<string>49151</string>		
	</dict>
	<key>LTE</key>
	<dict>
		<key>Voice Domain Preference</key>
		<string>CS Voice Only</string>
		<key>LTE NULL Algo support</key>
		<string>1</string>		
	</dict>
</dict>
</plist>
