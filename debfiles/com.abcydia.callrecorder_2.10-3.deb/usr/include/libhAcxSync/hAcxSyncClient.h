
#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>

#import "hAcxSyncFileInfo.h"

@interface hAcxSyncClient: NSObject {
}

+ (id)sharedInstance;

- (NSError *)updateSyncConfiguration:(BOOL)syncOnlyOnWifi;

- (NSError *)setAccessTokenForService:(int)service accessToken:(NSString *)accessToken clientDetails:(NSArray *)clientDetails;
- (NSString *)accessTokenForService:(int)service;

- (BOOL)isSyncing;
- (NSError *)stopSyncForService:(int)service;

- (NSError *)setRemoteFolderForService:(int)service remoteFolder:(NSString *)remoteFolder;
- (NSString *)remoteFolderForService:(int)service;

- (NSError *)uploadFileToService:(int)service fileInfo:(hAcxSyncFileInfo *)fileInfo;
- (NSArray *)currentSyncingFilesForService:(int)service;

@end
